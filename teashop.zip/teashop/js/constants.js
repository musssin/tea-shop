class Constants {
    static selectedItem = 'aa';
}