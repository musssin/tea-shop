class Constants {
    static selectedTeaName;
    static selectedTeaPrice;
    static selectedTeaOldPrice;
}
